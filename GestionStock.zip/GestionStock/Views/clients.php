<?php 
session_start();

if (!$_SESSION['pass']) {
    # code...
    header('Location:../index.php');
}
    require_once "../Models/clients.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/dashboard.css">
    <link rel="stylesheet" href="./css/produits.css">
    <title>CLIENTS</title>
</head>
<body>
    <header>
        <div class="logo"><a href="#">Nova <span>| Gest</span></a></div>
        <ul class="navbar">
            <li><a href="./Dashboard.php">Dashboard</a></li>
            <li><a href="./commandes.php">Commandes</a></li>
            <li><a href="./clients.php">Clients</a></li>
            <li><a href="./fournisseurs.php">Fournisseurs</a></li>
            <li><a href="./produits.php">Produits</a></li>
            <li><a href="./categorie.php">Categories</a></li>
            <li><a href="./lignesCommandes.php">Lignes Commandes</a></li>
            <li><a href="./deconnexion.php">Deconnexion</a></li>
        </ul>
    </header>
    <section>
        <div class="header" id="bag">
            <a href="#" id="cat">Clients</a>
            <div class="nav">
                <a href="./reseau.html"><input type="search" placeholder="Recherche..."></a>
                <button class="btn" id="ouvrir">Ajouter un client +</button>
            </div>
        </div>
        <?php 
            if (isset($_GET['id'])) {
                    # code...
                
                 echo '<script>
                    document.getElementById("bag").style.background="#000";
                let cat=document.getElementById("cat");
                cat.innerText="Modifier le client";
                cat.style.color="#fff";

                </script>';

            }
        ?>
        <?php 
            if (isset($msg))
                foreach ($msg as $ms) {
                    # code...
                    echo '<p>'.$ms.'</p>';
                }
        ?>
        <div class="for" id="form">
            <div class="boit">
                <h2 >Ajouter un client</h2>
                <p id="fermer">x</p>
            </div>
            <form action="" method="post">
                <input type="number" name="identifiant" placeholder="Id|Client">
                <input type="text" name="nom" placeholder="Nom complet">
                <input type="text" name="contact" placeholder="Contact">
                <input type="text" name="adr" placeholder=" ex. Q.kyeshero, av.kir, C.goma, 10">
                <button type="submit" id="btn1" name="send">Ajouter</button>
                <?php 
                   if (isset($_GET['id'])) {
                    # code...
                        echo '<button type="submit" id="btn2" name="modifier" style="background:red;">Modifier</button>';
                        echo '<script>
                            document.getElementById("btn1").style.display="none";
                        </script>';
                   }
                ?>
            </form>
        </div>

        <div class="table">
            <table>
                <thead>
                    <tr>
                        <td>Id</td>
                        <td>Nom</td> 
                        <td>Contact</td>
                        <td>Adresse</td>
                        <td>Actions</td>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if (true) {
                        # code...
                    
                        $req="SELECT * FROM clients";
                        $stmt=$pdo->query($req);
                        $stmt->execute();
                        $clients=$stmt->fetchAll();
                        foreach ($clients as $client) {
                            # code...
                    ?>
                    
                    <tr>
                        <td><?php echo $client['id']?></td>
                        <td><?php echo $client['nom']?></td> 
                        <td><?php echo $client['contact']?> </td>
                        <td><?php echo $client['adresse']?></td>
                        <td class="ha">
                            <a href="clients.php?id=<?php echo $client['id']?>">Edit</a> 
                            <a href="clients.php?nom=<?php echo $client['nom']?>">Delete</a>
                        </td>
                    </tr>
                    <?php
                     }
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <p class="p">&copy; Nova | Gest | David | MVUNABO | 2024 | Goma</p>
    </section>
    <script src="../Views/js/addProd.js"></script>
</body>
</html>