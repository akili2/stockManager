<?php 
    try {
        require_once "../config.php";
        function ajouterCommande(){
            global $pdo;
            if (isset($_POST['add'])) {
                # code...
                $id=$_POST['id'];
                $client=$_POST['client'];
                $fournisseur=$_POST['fournisseur'];
                $etat=$_POST['etat'];
                $req="INSERT INTO commandes (id,date,client_id,fournisseur_id,etat) VALUES (:id,NOW(),:client_id,:fournisseur_id,:etat)";
                $stmt=$pdo->prepare($req);
                $stmt->bindParam(':id',$id);
                $stmt->bindParam(':client_id',$client);
                $stmt->bindParam(':fournisseur_id',$fournisseur);
                $stmt->bindParam(':etat',$etat);
                $stmt->execute();
                header('location:./commandes.php');

            }
            if (isset($_GET['id'])) {
                # code...
                $id=$_GET['id'];
                $req="DELETE FROM commandes WHERE id=:id";
                $stmt=$pdo->prepare($req);
                $stmt->bindParam(':id',$id);
                $stmt->execute();
                header('location: ../views/commandes.php');
            }
            if (isset($_POST['modifier'])) {
                # code...
                $client_id=$_GET['client_id'];
                $etat=$_POST['etat'];
                $req="UPDATE  commandes SET etat=:etat WHERE client_id=:client_id";
                $stmt=$pdo->prepare($req);
                $stmt->bindParam(':client_id',$client_id);
                $stmt->bindParam(':etat',$etat);
                $stmt->execute();
                header('location:./commandes.php');

            }
        }

    } catch (PDOException $e) {
        echo'Erreur : '.$e->getMessage();
    }
?>