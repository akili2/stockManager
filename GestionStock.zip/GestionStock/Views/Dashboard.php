<?php
session_start();

if (!$_SESSION['pass']) {
    # code...
    header('Location:../index.php');
}
   require "../config.php";
   function fournisseur_a(){
      global $pdo;
      $sql=$pdo->prepare("SELECT fournisseur_id FROM commandes");
      $sql->execute();
      $rowCount=$sql->rowCount();
    
         echo $rowCount;
    
   }
   function client_a(){
    global $pdo;
    $sql=$pdo->prepare("SELECT client_id FROM commandes");
    $sql->execute();
    $rowCount=$sql->rowCount();
  
       echo $rowCount;
  
 }
 function fournisseur(){
    global $pdo;
    $sql=$pdo->prepare("SELECT * FROM fournisseurs");
    $sql->execute();
    $rowCount=$sql->rowCount();
  
       echo $rowCount;
  
 }
 function client(){
    global $pdo;
    $sql=$pdo->prepare("SELECT * FROM clients");
    $sql->execute();
    $rowCount=$sql->rowCount();
  
       echo $rowCount;
  
 }
 function produit(){
    global $pdo;
    $sql=$pdo->prepare("SELECT * FROM produits");
    $sql->execute();
    $rowCount=$sql->rowCount();
  
       echo $rowCount;
  
 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/dashboard.css">
    <title>DASHBOARD</title>
</head>
<body>
    <header>
        <div class="logo"><a href="#">Nova <span>| Gest</span></a></div>
        <ul class="navbar">
            <li><a href="./Dashboard.php">Dashboard</a></li>
            <li><a href="./commandes.php">Commandes</a></li>
            <li><a href="./clients.php">Clients</a></li>
            <li><a href="./fournisseurs.php">Fournisseurs</a></li>
            <li><a href="./produits.php">Produits</a></li>
            <li><a href="./categorie.php">Categories</a></li>
            <li><a href="./lignesCommandes.php">Lignes Commandes</a></li>
            <li><a href="./deconnexion.php">Deconnexion</a></li>
        </ul>
    </header>
    <section id="div">
        <div class="header">
            <a href="#">DASHBOARD</a>
            <div class="nav">
                <p><?php echo $_SESSION['user']?></p>
                <p>Connecté</p>
            </div>
        </div>
        <div class="container">
            <div class="content">
                <h2>Plus utilisés</h2>
                <P><?php client_a(); ?> Clients réguliers</P>
                <p><?php fournisseur_a();?> fournisseurs réguliers</p>
            </div>
            <div class="content">
                <h2>Situations stock</h2>
                <P><?php produit();?> produits en stock</P>
            </div>
            <div class="content">
                <h2>Nombres des clients</h2>
                <P><?php client(); ?> Clients </P> 
            </div>
            <div class="content">
                <h2>Nombres des Fournisseurs</h2>
                <P> <?php fournisseur(); ?> fournisseurs </P> 
            </div>
        </div>
        <p class="p">&copy; Nova | Gest | David | MVUNABO | 2024 | Goma</p> <button class="btn" onclick="print()"  >impprimer</button>
        <script src="./js.print.js"></script>
        <style>
            .btn{
                background-color: #b00000;
                padding: 10px 20px;
                color: #fff;
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 100;
            }
        </style>
    </section>
</body>
</html>