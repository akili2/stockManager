function imprimer() {
    let div=document.getElementById('div');
    let fenetrePrint=window.open(".",'height=400,width=600');
    fenetrePrint.document.write(div.innerHTML);
    fenetrePrint.document.close();
    fenetrePrint.print();
}