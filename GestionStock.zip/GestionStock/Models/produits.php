<?php 
    try {
        require_once "../config.php";
        function ajouterProduit(){
            global $pdo;
            if (isset($_POST['send'])) {
                # code...
                $id=$_POST['Id'];
                $Nproduit=$_POST['Nproduit'];
                $Description=$_POST['Description'];
                $cat=$_POST['cat'];
                $prix=$_POST['prix'];
                $stock=$_POST['stock'];
                $req="INSERT INTO produits(id,nom,description,categorie,prix,stock) VALUES (:id,:nom,:description,:categorie,:prix,:stock)";
                $stmt=$pdo->prepare($req);
                $stmt->bindParam(':id',$id);
                $stmt->bindParam(':nom',$Nproduit);
                $stmt->bindParam(':description',$Description);
                $stmt->bindParam(':categorie',$cat);
                $stmt->bindParam(':prix',$prix);
                $stmt->bindParam(':stock',$stock);
                $stmt->execute();
                header('location:./produits.php');
            }
            if (isset($_POST['modifier'])) {
                # code...
                $nom=$_GET['nom'];
                $id=$_POST['Id'];
                $Nproduit=$_POST['Nproduit'];
                $Description=$_POST['Description'];
                $cat=$_POST['cat'];
                $prix=$_POST['prix'];
                $stock=$_POST['stock'];
                $req="UPDATE produits SET id=:id,nom=:nom,description=:description,categorie=:categorie,prix=:prix,stock=:stock";
                $stmt=$pdo->prepare($req);
                $stmt->bindParam(':id',$id);
                $stmt->bindParam(':nom',$Nproduit);
                $stmt->bindParam(':description',$Description);
                $stmt->bindParam(':categorie',$cat);
                $stmt->bindParam(':prix',$prix);
                $stmt->bindParam(':stock',$stock);
                $stmt->execute();
                header('location:./produits.php');
                $msg[]="Produits modifier avec succes";
            }
            if (isset($_GET['id'])) {
                # code...
                $id=$_GET['id'];
                $req="DELETE FROM produits WHERE id=:id";
                $stmt=$pdo->prepare($req);
                $stmt->bindParam(':id',$id);
                
                $stmt->execute();
                header('location:./produits.php');


            }
        }

    } catch (PDOException $e) {
        echo'Erreur : '.$e->getMessage();
    }
?>