var ouvrir=document.getElementById('ouvrir');
var fermer=document.getElementById('fermer');
var form =document.getElementById('form');

function Show() {
    form.style.display='block';
}
function close() {
    form.style.display='none';
}
ouvrir.addEventListener('click',Show);
fermer.addEventListener('click',close);


