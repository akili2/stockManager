<?php
session_start();

if (!$_SESSION['pass']) {
    # code...
    header('Location:../index.php');
}
    require "../Models/lignesCommandes.php";
    ajouterlignes();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/dashboard.css">
    <link rel="stylesheet" href="./css/produits.css">
    <title>L-COMM</title>
</head>
<body>
    <header>
        <div class="logo"><a href="#">Nova <span>| Gest</span></a></div>
        <ul class="navbar">
            <li><a href="./Dashboard.php">Dashboard</a></li>
            <li><a href="./commandes.php">Commandes</a></li>
            <li><a href="./clients.php">Clients</a></li>
            <li><a href="./fournisseurs.php">Fournisseurs</a></li>
            <li><a href="./produits.php">Produits</a></li>
            <li><a href="./categorie.php">Categories</a></li>
            <li><a href="./lignesCommandes.php">Lignes Commandes</a></li>
            <li><a href="./deconnexion.php">Deconnexion</a></li>
        </ul>
    </header>
    <section>
        <div class="header" id="bag">
            <a href="#" id="cat">Lignes des commandes</a>
            <div class="nav">
                <a href="./reseau.html"><input type="search" placeholder="Recherche..."></a>
                <button class="btn" id="ouvrir">Ajouter une ligne de commande</button>
            </div>
        </div>
        <?php 
            if (isset($_GET['id'])) {
                    # code...
                
                 echo '<script>
                    document.getElementById("bag").style.background="#09001f";
                let cat=document.getElementById("cat");
                cat.innerText="Modifier la ligne de commande";
                cat.style.color="#fff";

                </script>';

            }
        ?>
        <div class="for" id="form">
            <div class="boit">
                <h2 >Ajouter une ligne de commande</h2>
                <p id="fermer">x</p>
            </div>
            <form action="" method="post">
                <select name="commande">
                    <option value="" selected>Commande_id</option>
                    <?php
                        $req="SELECT * FROM commandes";
                        $stmt=$pdo->prepare($req);
                        $stmt->execute();
                        $clients=$stmt->fetchAll();
                        foreach($clients as $client){
                            
                        
                    ?>
                              <option value="<?php echo $client['id']?>"> <?php echo $client['id']?> </option>
                    <?php
                    }
                    ?>
                </select>
                <select name="produit">
                    <option value="" selected>Produit_id</option>
                    <?php
                        $req="SELECT * FROM produits";
                        $stmt=$pdo->prepare($req);
                        $stmt->execute();
                        $clients=$stmt->fetchAll();
                        foreach($clients as $client){
                            
                        
                    ?>
                              <option value="<?php echo $client['nom']?>"> <?php echo $client['nom']?> </option>
                    <?php
                    }
                    ?>
                </select>
                <input type="text" name="quantite" placeholder="Quantité">
                <input type="number" name="prix" placeholder="Prix unitaire">
                <button type="submit" id="btn1" name="add">Ajouter</button>
                <?php 
                   if (isset($_GET['id'])) {
                    # code...
                        echo '<button type="submit" id="btn2" name="modifier" style="background:#b00000; color:#fff;">Modifier</button>';
                        echo '<script>
                            document.getElementById("btn1").style.display="none";
                        </script>';
                   }
                ?>
            </form>
        </div>
        <div class="table">
            <table>
                <thead>
                    
                    <tr>
                        <td>Id</td>
                        <td>Comande_id</td> 
                        <td>Produit_id</td>
                        <td>Quantité</td>
                        <td>Prix|unit</td>
                        <td>Total</td>
                        <td>Actions</td>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $req="SELECT * FROM lignescommandes";
                    $stmt=$pdo->query($req);
                    $produits=$stmt->fetchAll();
                    foreach ($produits as $produit) {
                        # code...
                    ?>
                    <tr>
                        <td><?php echo $produit['id']?></td>
                        <td><?php echo $produit['commande_id']?></td> 
                        <td><?php echo $produit['produit_id']?></td>
                        <td id="quantite"><?php echo $produit['quantite']?> boites</td>
                        <td id="prix"><?php echo $produit['prix_unitaire']?> <span>$</span></td>
                        <td class="tot" id="total">-- <span>$</span></td>
                        
                        <td class="ha">
                            <a href="lignescommandes.php?id=<?php echo $produit['id']?>">Edit</a> 
                            <a href="lignescommandes.php?commande_id=<?php echo $produit['commande_id']?>">Delete</a>
                        </td>
                    </tr>
                    <?php 
                    }
                    
                    ?>
                    
                </tbody>
            </table>
        </div>
        
        <p class="p">&copy; Nova | Gest | David | MVUNABO | 2024 | Goma</p>
    </section>
    <script src="./js/addProd.js"></script>
</body>
</html>