
<?php 
    try {
        require_once "../config.php";

        if (isset($_POST['enregister'])) {
            # code...
            $nom=$_POST['nom'];
            $req="INSERT INTO categorie (nom) VALUE (:nom)";
            $stmt=$pdo->prepare($req);
            $stmt->bindParam(':nom',$nom);
            if ($stmt->execute()) {
                # code...
                header('location: ../Views/categorie.php');
            }
        }
        
        function modifier(){
            global $pdo;
            if (isset($_POST['modifier'])) {
                # code...
                if ($_GET['id']) {
                    # code...
                    $id=$_GET['id'];
                    $nom=$_POST['nom'];
                    $req="UPDATE categorie SET nom =:nom WHERE id=:id ";
                    $stmt=$pdo->prepare($req);
                    $stmt->bindParam(':nom',$nom);
                    $stmt->bindParam(':id',$id);
                    if ($stmt->execute()) {
                        # code...
                        header('location: ../Views/categorie.php');
                    }
                }
                
            }
        };

    } catch (PDOException $e) {
        echo'Erreur : '.$e->getMessage();
    }

    
?>