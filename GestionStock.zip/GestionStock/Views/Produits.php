<?php 
session_start();

if (!$_SESSION['pass']) {
    # code...
    header('Location:../index.php');
}
    require "../Models/produits.php";
    ajouterProduit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/dashboard.css">
    <link rel="stylesheet" href="./css/produits.css">
    <title>PRODUITS</title>
</head>
<body>
    <header>
        <div class="logo"><a href="#">Nova <span>| Gest</span></a></div>
        <ul class="navbar">
            <li><a href="./Dashboard.php">Dashboard</a></li>
            <li><a href="./commandes.php">Commandes</a></li>
            <li><a href="./clients.php">Clients</a></li>
            <li><a href="./fournisseurs.php">Fournisseurs</a></li>
            <li><a href="./produits.php">Produits</a></li>
            <li><a href="./categorie.php">Categories</a></li>
            <li><a href="./lignesCommandes.php">Lignes Commandes</a></li>
            <li><a href="./deconnexion.php">Deconnexion</a></li>
        </ul>
    </header>
    <section>
        <div class="header" id="bag">
            <a href="#" id="cat">Produits</a>
            <div class="nav">
                <a href="./reseau.html"><input type="search" placeholder="Recherche..."></a>
                <button class="btn" id="ouvrir">Ajouter produit +</button>
            </div>
        </div>
        <?php 
            if (isset($_GET['nom'])) {
                    # code...
                
                 echo '<script>
                    document.getElementById("bag").style.background="#b8fdcd";
                let cat=document.getElementById("cat");
                cat.innerText="Modifier le produit";
                cat.style.color="#000";

                </script>';

            }
        ?>
        <div class="for" id="form">
            <div class="boit">
                <h2 >Ajouter un Produit</h2>
                <p id="fermer">x</p>
            </div>
            <form action="" method="post">
                <input type="number" name="Id" placeholder="Id">
                <input type="text" name="Nproduit" placeholder="Nom produit">
                <textarea name="Description" id="" placeholder="Description"></textarea>
                <select name="cat">
                    <option value="" selected>choix Categorie</option>
                    <?php
                        $req="SELECT * FROM categorie";
                        $stmt=$pdo->query($req);
                        $options=$stmt->fetchAll();
                        foreach ($options as $option) {
                            # code...
                        ?>
                            <option value="<?php echo $option['nom']?>" selected><?php echo $option['nom']?></option>
                        <?php
                        }
                    ?>
                </select>
                <input type="number" name="prix" placeholder="Prix unitaire">
                <input type="number" name="stock" placeholder="stock">
                <button type="submit" id="btn1" name="send">Ajouter</button>
                <?php 
                   if (isset($_GET['nom'])) {
                    # code...
                        echo '<button type="submit" id="btn2" name="modifier" style="background:#b00000; color:#fff;">Modifier</button>';
                        echo '<script>
                            document.getElementById("btn1").style.display="none";
                        </script>';
                   }
                ?>
            </form>
        </div>
        <div class="table">
            <table>
                <thead>
                    <?php 
                       if (isset($msg)) {
                        # code...
                        foreach ($msg as $message) {
                            # code...
                            echo '<p>'.$message.'</p>';
                        }
                       }
                    ?>
                    <tr>
                        <td>Id</td>
                        <td>Nom_Produit</td> 
                        <td>Description</td>
                        <td>Catégorie</td>
                        <td>Prix|unit</td>
                        <td>Stock</td>
                        <td>Actions</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $req="SELECT * FROM produits";
                        $stmt=$pdo->query($req);
                        $produits=$stmt->fetchAll();
                        foreach ($produits as $produit) {
                            # code...
                        ?>
                            
                        
                    <tr>
                        <td><?php echo $produit['id']?></td>
                        <td><?php echo $produit['nom']?></td> 
                        <td><?php echo $produit['description']?></td>
                        <td><?php echo $produit['categorie']?></td>
                        <td><?php echo $produit['prix']?> <span>$</span></td>
                        <td><?php echo $produit['stock']?> <span>box</span></td>
                        <td class="ha">
                            <a href="./produits.php?nom=<?php echo $produit['nom']?>">Edit</a> 
                            <a href="./produits.php?id=<?php echo $produit['id']?>">Delete</a>
                        </td>
                    </tr>
                    <?php
                        }
                    ?>
                </tbody>
            </table>
        </div>
        
        <p class="p">&copy; Nova | Gest | David | MVUNABO | 2024 | Goma</p>
    </section>
    <script src="./js/addProd.js"></script>
</body>
</html>