<?php 

session_start();

if (!$_SESSION['pass']) {
    # code...
    header('Location:../index.php');
}
    require_once "../Models/Categories.php";
    modifier();
    if (isset($_GET['nom'])) {
        # code...
        $nom=$_GET['nom'];
        $req="DELETE  FROM categorie WHERE nom=:nom";
        $stmt=$pdo->prepare($req);
        $stmt->bindParam(':nom',$nom);
        $stmt->execute();
        if ($stmt->execute()) {
            # code...
            header('location: ../Views/categorie.php');
        }
    
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/dashboard.css">
    <link rel="stylesheet" href="./css/produits.css">
    <title>CATEGORIES</title>
</head>
<body>
<header>
        <div class="logo"><a href="#">Nova <span>| Gest</span></a></div>
        <ul class="navbar">
            <li><a href="./Dashboard.php">Dashboard</a></li>
            <li><a href="./commandes.php">Commandes</a></li>
            <li><a href="./clients.php">Clients</a></li>
            <li><a href="./fournisseurs.php">Fournisseurs</a></li>
            <li><a href="./produits.php">Produits</a></li>
            <li><a href="./categorie.php">Categories</a></li>
            <li><a href="./lignesCommandes.php">Lignes Commandes</a></li>
            <li><a href="./deconnexion.php">Deconnexion</a></li>
        </ul>
</header>
    <section id="div">
        <div class="header" id="bag">
            <a href="#" id="cat">Categories</a>
            <div class="nav">
                <a href="./reseau.html"><input type="search" placeholder="Recherche..."></a>
                <button class="btn" id="ouvrir">Ajouter une categorie</button>
            </div>
        </div>
        <?php 
            if (isset($_GET['id'])) {
                    # code...
                
                 echo '<script>
                    document.getElementById("bag").style.background="#09001f";
                let cat=document.getElementById("cat");
                cat.innerText="Modifier la Categorie";

                </script>';

            }
        ?>
        <div class="for" id="form" >
            <div class="boit">
                <h2 >Ajouter une categorie</h2>
                <p id="fermer">x</p>
            </div>
            <form action="" method="post">
                <input type="text" name="nom" placeholder="Nom categorie">
                <button type="submit" id="btn1" name="enregister">Ajouter</button>
                <?php 
                   if (isset($_GET['id'])) {
                    # code...
                        echo '<button type="submit" id="btn2" name="modifier" style="background:red;">Modifier</button>';
                        echo '<script>
                            document.getElementById("btn1").style.display="none";
                        </script>';
                   }
                ?>
            </form>
        </div>
        <div class="table">
            <table>
                <thead>
                    <tr>
                        <td>Id</td>
                        <td>Nom</td> 
                        <td>Actions</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        
                            # code...
                        
                        $req="SELECT * FROM categorie";
                        $stmt = $pdo->prepare($req);
                        $stmt->execute();
                        $categories = $stmt->fetchAll();
                        foreach ($categories as $categorie) {
                                # code...
                        ?>
                        <tr>
                            <td><?php echo $categorie['id']?></td>
                            <td><?php echo $categorie['nom']?></td>
                            <td class="ha">
                                <a href="categorie.php?id=<?php echo $categorie['id']?>">Edit</a> 
                                <a href="categorie.php?nom=<?php echo $categorie['nom']?>">Delete</a>
                            </td>
                        </tr>
                        <?php 
                        }
                        
                    ?>
                </tbody>
            </table>
        </div>
        
        <p class="p">&copy; Nova | Gest | David | MVUNABO | 2024 | Goma</p> <button class="btn1" onclick="print()"  >impprimer</button>
        <script src="./js/print.js"></script>
        <script src="./js/addProd.js"></script>
        <style>
            .btn1{
                background-color: #b00000;
                padding: 10px 20px;
                color: #fff;
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 100;
            }
        </style>
</body>
</html>