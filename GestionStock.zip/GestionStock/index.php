<?php
session_start();

if (isset($_POST['conn'])) {
    # code...
    $pseudo=$_POST['user'];
    $mdp=$_POST['pass'];
    if (!empty($pseudo) && !empty($mdp) ) {
        # code...
        $_SESSION['user']= $pseudo;
        $_SESSION['pass']= $mdp;
        header("location:./views/dashboard.php");
        
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./Views/css/index.css">
    <title>Connexion </title>
</head>
<body>
    <div class="form">
        <form action="" method="post">
            <h2>Se connecter</h2>
            <div class="content">
                <label for="">Operant</label>
                <input type="text" name="user">
            </div>
            <div class="content">
                <label for="">Mot de passe</label>
                <input type="password" name="pass">
            </div>
            <button type="submit" name="conn">Se connecter</button>
        </form>

        <p>&copy;AppGestion | de stock | 2024</p>
    </div>
</body>
</html>