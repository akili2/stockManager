<?php
     try {
        
        require "../config.php";
        function ajouterlignes(){
            global $pdo;

            if (isset($_POST['add'])) {
                # code...
                $commande=$_POST['commande'];
                $produit=$_POST['produit'];
                $quantite=$_POST['quantite'];
                $prix=$_POST['prix'];
                $req="INSERT INTO lignescommandes(commande_id,produit_id,quantite,prix_unitaire) VALUES (:commande,:produit,:quantite,:prix)";
                $stmt=$pdo->prepare($req);
                $stmt->bindParam(':commande',$commande);
                $stmt->bindParam(':produit',$produit);
                $stmt->bindParam(':quantite',$quantite);
                $stmt->bindParam(':prix',$prix);
                $stmt->execute();
                header('location:lignescommandes.php');
            }
            if (isset($_POST['modifier'])) {
                # code...
                $id=$_GET['id'];
                $commande=$_POST['commande'];
                $produit=$_POST['produit'];
                $quantite=$_POST['quantite'];
                $prix=$_POST['prix'];
                $req="UPDATE lignescommandes SET commande_id=:commande,produit_id=:produit,quantite=:quantite,prix_unitaire=:prix WHERE id=:id";
                $stmt=$pdo->prepare($req);
                $stmt->bindParam(':id',$id);
                $stmt->bindParam(':commande',$commande);
                $stmt->bindParam(':produit',$produit);
                $stmt->bindParam(':quantite',$quantite);
                $stmt->bindParam(':prix',$prix);
                $stmt->execute();
                header('location:lignescommandes.php');
            }
            if (isset($_GET['commande_id'])) {
                # code...
                $id=$_GET['commande_id'];
                $req="DELETE FROM lignescommandes WHERE commande_id=:id";
                $stmt=$pdo->prepare($req);
                $stmt->bindParam(':id',$id);
                $stmt->execute();
                header('location:./lignescommandes.php');
            }
        }
     } catch (PDOException $e) {
        echo'Erreur : '.$e->getMessage();
    }
