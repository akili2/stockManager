<?php 
    try {
        require_once "../config.php";
        if (isset($_POST['send'])) {
            # code...
            $id=$_POST['identifiant'];
            $nom=$_POST['nom'];
            $contact=$_POST['contact'];
            $adr=$_POST['adr'];
            $req="INSERT INTO fournisseurs (id,nom,contact,adresse) VALUES (:id,:nom,:contact,:adr)";
            $stmt=$pdo->prepare($req);
            $stmt->bindParam(':id',$id);
            $stmt->bindParam(':nom',$nom);
            $stmt->bindParam(':contact',$contact);
            $stmt->bindParam(':adr',$adr);
            if ($stmt->execute()) {
                # code...
                $msg[]="fournisseurs Enregistrer avec succes";
                header('location: ../views/fournisseurs.php');
                
            }
            else{
                $msg[]="Erreur dans l'enregistrement";
                header('location: ../views/fournisseurs.php');
            }

        }
        if (isset($_POST["modifier"])) {
            # code...
            $id=$_GET["id"];
            $nom=$_POST['nom'];
            $contact=$_POST['contact'];
            $adr=$_POST['adr'];
            $req="UPDATE fournisseurs SET nom=:nom,contact=:contact,adresse=:adr WHERE id=:id";
            $stmt=$pdo->prepare($req);
            $stmt->bindParam(':id',$id);
            $stmt->bindParam(':nom',$nom);
            $stmt->bindParam(':contact',$contact);
            $stmt->bindParam(':adr',$adr);
            if ($stmt->execute()) {
                # code...
                $msg[]="fournisseurs Enregistrer avec succes";
                header('location: ../views/fournisseurs.php');
                
            }
            else{
                $msg[]="Erreur dans l'enregistrement";
                header('location: ../views/fournisseurs.php');
            }

        }
        if (isset($_GET['nom'])) {
            # code...
            $nom=$_GET['nom'];
            $req="DELETE FROM fournisseurs WHERE nom=:nom";
            $stmt=$pdo->prepare($req);
            $stmt->bindParam(':nom',$nom);
            $stmt->execute();
            header('location: ../views/fournisseurs.php');
        }

    } catch (PDOException $e) {
        echo'Erreur : '.$e->getMessage();
    }
?>