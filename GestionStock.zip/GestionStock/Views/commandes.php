<?php 
session_start();

if (!$_SESSION['pass']) {
    # code...
    header('Location:../index.php');
}
    require_once "../Models/Commandes.php";
    ajouterCommande();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/dashboard.css">
    <link rel="stylesheet" href="./css/produits.css">
    <title>COMMANDE</title>
</head>
<body>
    <header>
        <div class="logo"><a href="#">Nova <span>| Gest</span></a></div>
        <ul class="navbar">
            <li><a href="./Dashboard.php">Dashboard</a></li>
            <li><a href="./commandes.php">Commandes</a></li>
            <li><a href="./clients.php">Clients</a></li>
            <li><a href="./fournisseurs.php">Fournisseurs</a></li>
            <li><a href="./produits.php">Produits</a></li>
            <li><a href="./categorie.php">Categories</a></li>
            <li><a href="./lignesCommandes.php">Lignes Commandes</a></li>
            <li><a href="./deconnexion.php">Deconnexion</a></li>
        </ul>
    </header>
    <section>
        <div class="header" id="bag">
            <a href="#" id="cat">Commandes</a>
            <div class="nav">
                <a href="./reseau.html"><input type="search" placeholder="Recherche..."></a>
                <button class="btn" id="ouvrir">Ajouter une commande</button>
            </div>
        </div>
        <?php 
            if (isset($_GET['client_id'])) {
                    # code...
                
                 echo '<script>
                    document.getElementById("bag").style.background="#09001f";
                let cat=document.getElementById("cat");
                cat.innerText="Modifier la commande";
                cat.style.color="#fff";

                </script>';

            }
        ?>
        <div class="for" id="form">
            <div class="boit">
                <h2 >Ajouter une commande</h2>
                <p id="fermer">x</p>
            </div>
            <form action="" method="post">
                <input type="number" name="id" id="op" placeholder="Id">
                <select name="client" id="op1">
                    <option value="" selected>Ajouter un  Client</option>
                    <?php
                        $req="SELECT * FROM clients";
                        $stmt=$pdo->prepare($req);
                        $stmt->execute();
                        $clients=$stmt->fetchAll();
                        foreach($clients as $client){
                            
                        
                    ?>
                              <option value="<?php echo $client['id'].' '.$client['nom']?>"> <?php echo $client['id'].' '.$client['nom']?> </option>
                    <?php
                    }
                    ?>
                </select>
                <select name="fournisseur" id="op2">
                    <option value="" selected>Ajouter un fournisseur</option>
                    <?php
                        $req="SELECT * FROM fournisseurs";
                        $stmt=$pdo->prepare($req);
                        $stmt->execute();
                        $fournisseurs=$stmt->fetchAll();
                        foreach($fournisseurs as $fournisseur){
                            
                        
                    ?>
                            <option value="<?php echo $fournisseur['id'].' '.$fournisseur['nom']?>"> <?php echo $fournisseur['id'].' '.$fournisseur['nom']?> </option>
                    <?php
                    }
                    ?>
                </select>
                <select name="etat">
                    <option value="En attente" selected>En attente</option>
                    <option value="Livré">Livré</option>
                    <option value="Expédié">Expédié</option>
                </select>
                <button type="submit" id="btn1" name="add">Ajouter</button>
                <?php 
                 if (isset($_GET['client_id'])) {
                    # code...
                        echo '<button type="submit" id="btn2" name="modifier" style="background:#b00000; color:#fff;">Modifier</button>';
                        echo '<script>
                            document.getElementById("btn1").style.display="none";
                            document.getElementById("op").style.display="none";
                            document.getElementById("op1").style.display="none";
                            document.getElementById("op2").style.display="none";
                        </script>';
                   }
                ?>
            </form>
        </div>

        <div class="table">
            <table>
                <thead>
                    
                    <tr>
                        <td>Id</td>
                        <td>Date</td> 
                        <td>Client_id</td>
                        <td>Fournisseur_id</td>
                        <td>Etat</td>
                        <td>Actions</td>
                    </tr>
                </thead>
                <tbody>
                <?php
                        $req="SELECT * FROM commandes";
                        $stmt=$pdo->query($req);
                        $produits=$stmt->fetchAll();
                        foreach ($produits as $produit) {
                            # code...
                        ?>
                            
                        
                    <tr>
                        <td><?php echo $produit['id']?></td>
                        <td><?php echo $produit['date']?></td> 
                        <td><?php echo $produit['client_id']?></td>
                        <td><?php echo $produit['fournisseur_id']?></td>
                        <td id="etat"><?php echo $produit['etat']?></td>
                        <td class="ha">
                            <a href="./commandes.php?client_id=<?php echo $produit['client_id']?>">Edit</a> 
                            <a href="./commandes.php?id=<?php echo $produit['id']?>">Delete</a>
                        </td>
                        <script>
                        let etat=document.getElementById('etat');
                        let valeur=etat.textContent;
                        if (valeur=="Livré") {
                            etat.style.color="#2cc277";
                        }else if (valeur=="Expédié") {
                            etat.style.color="#2c98c2";
                        }else{
                            etat.style.color="#c22c2c";
                        }
                   </script>
                    </tr>
                    
                    <?php
                        }
                    ?>
                   
                </tbody>
            </table>
        </div>
        
        <p class="p">&copy; Nova | Gest | David | MVUNABO | 2024 | Goma</p>
    </section>
    <script src="./js/addProd.js"></script>
</body>
</html>